import React from "react";

function CreateNewOrder(props) {
  return <div>CreateNewOrder</div>;
}

export default CreateNewOrder;
