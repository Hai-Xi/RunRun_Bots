import React from "react";

function Landing(props) {
  return <div>landing</div>;
}

export default Landing;
